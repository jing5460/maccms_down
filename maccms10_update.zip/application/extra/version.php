<?php
return array (
    'name' => '苹果CMS内容管理系统',
    'copyright' => 'MacCMS',
    'url' => '//github.com/magicblack',
    'code' => '2020.1000.1060',
    'license' => '免费版',
);
?>