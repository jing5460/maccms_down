<?php
return array (
    'name' => '苹果CMS',
    'copyright' => 'MacCMS',
    'url' => '//github.com/magicblack',
    'code' => '2020.1000.1053',
    'license' => '免费版',
);
?>