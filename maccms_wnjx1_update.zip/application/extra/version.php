<?php
return array (
    'name' => '苹果CMS万能镜像',
    'copyright' => 'MacCMS',
    'url' => '//github.com/magicblack',
    'code' => '2020.1000.1003',
    'license' => '免费版',
);
?>