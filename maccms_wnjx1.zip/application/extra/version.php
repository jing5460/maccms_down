<?php
return array (
    'name' => '苹果CMS万能镜像系统',
    'copyright' => 'MacCMS',
    'url' => '//github.com/magicblack',
    'code' => '2020.1000.1006',
    'license' => '免费版',
);
?>