<?php
return array (
  '__pattern__' =>
  array (
    'p' => '[\\s\\S]*?',
  ),
  '<p?>' =>
  array (
    0 => 'index/index',
    1 =>
    array (
    ),
    2 =>
    array (
    ),
  ),
);